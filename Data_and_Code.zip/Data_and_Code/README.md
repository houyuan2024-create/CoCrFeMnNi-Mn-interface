# CoCrFeMnNi interface solidification

Data and programs accompanying “Mn migration and liquid-side enrichment at CoCrFeMnNi solidification interfaces”.

## Contents

| Directory | Contents | Manuscript results |
|---|---|---|
| `EPMA/` | Raw maps for six fields, acquisition parameters and composition analysis | Fig. 2, Fig. S1 and Table S1 |
| `MD/simulation/` | Alloy construction, three replica parameter sets, interface preparation and solidification inputs | Model and thermal conditions in Sections 2.2 and S2 |
| `MD/potentials/` | Elemental and five-component MEAM parameter files | Interatomic interactions |
| `MD/analysis/` | Interface, composition, chemical-order and Mn trajectory analysis | Figs. 3–7, Figs. S2–S3 and Table S2 |

Each directory contains instructions for its calculation. Paths are relative to the package. EPMA field numbers follow Table S1, and MD replica numbers follow Table S2. The potential-library element order and the simulation atom-type order are specified in the LAMMPS inputs.

## Calculation sequence

1. Run the EPMA processing program on the supplied raw maps.
2. Generate and prepare each of the three MD replicas, then run solidification with the supplied LAMMPS inputs.
3. Process each generated trajectory and combine the three replicas using the analysis programs.

Run the following commands from `Data_and_Code`. Replace `lmp_mpi` with the installed LAMMPS executable; the example uses the reported 96 MPI ranks per replica.

```sh
python -m pip install -r EPMA/requirements.txt
python EPMA/process_epma.py
python EPMA/plot_epma.py
python MD/simulation/run_replica.py --replica 1 --lammps "mpirun -np 96 lmp_mpi" --output MD_runs/replica_01
python MD/simulation/run_replica.py --replica 2 --lammps "mpirun -np 96 lmp_mpi" --output MD_runs/replica_02
python MD/simulation/run_replica.py --replica 3 --lammps "mpirun -np 96 lmp_mpi" --output MD_runs/replica_03
python MD/analysis/run_analysis.py --simulation-root MD_runs --out MD_results
```

Simulation outputs are generated during these calculations. Full trajectories, restart files, job logs and previously calculated result tables are not distributed here. A production trajectory occupies approximately 38.5 GB per replica. The random seeds and model construction are specified explicitly; subsequent atomic paths may vary with the LAMMPS build, parallel decomposition and floating-point arithmetic. The three replicas are the statistical units.
