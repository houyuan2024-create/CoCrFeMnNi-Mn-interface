# CoCrFeMnNi 2NN-MEAM potential

The two parameter files are the unmodified files used for the simulations:

| File | SHA-256 |
|---|---|
| `library.meam` | `3948e51e15f706e29bd8fee24944a9043be418b611ad8748e7efcc2d8df6f1cb` |
| `CoNiCrFeMn.meam` | `11d8c6a2ca849ead980585c8acca1b56088b8d88ee006c6127d09f57b20d5aea` |

The element order in the MEAM library is Co, Ni, Cr, Fe, Mn. The simulation atom-type order is Co, Cr, Fe, Mn, Ni. The `pair_coeff` commands in the supplied LAMMPS inputs implement this mapping explicitly.

References:

1. W. M. Choi, Y. Kim, D. Seol, B. J. Lee, Modified embedded-atom method interatomic potentials for the Co–Cr, Co–Fe, Co–Mn, Cr–Mn and Mn–Ni binary systems, Computational Materials Science 130 (2017) 121–129. https://doi.org/10.1016/j.commatsci.2017.01.002
2. W. M. Choi, Y. H. Jo, S. S. Sohn, S. Lee, B. J. Lee, Understanding the physical metallurgy of the CoCrFeMnNi high-entropy alloy: an atomistic simulation study, npj Computational Materials 4 (2018) 1. https://doi.org/10.1038/s41524-017-0060-9

These are third-party scientific parameter files. Their use and redistribution are subject to any terms established by their original providers; this repository does not grant an additional license for them.
