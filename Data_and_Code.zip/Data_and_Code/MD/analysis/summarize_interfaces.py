#!/usr/bin/env python3
"""Summarize three independent replicas using the manuscript estimators."""
import argparse
from collections import defaultdict
import csv
import math
from pathlib import Path
import statistics

ELEMENTS = ('Co', 'Cr', 'Fe', 'Mn', 'Ni')
REPLICAS = ('replica_01', 'replica_02', 'replica_03')


def read_csv(path):
    with Path(path).open(newline='', encoding='utf-8') as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows):
    if not rows:
        raise ValueError(f'No rows for {Path(path).name}')
    with Path(path).open('w', newline='', encoding='utf-8') as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def mean_interval(values):
    values = list(map(float, values))
    if len(values) != 3:
        raise ValueError('Exactly three independent replicas are required')
    mean = statistics.fmean(values)
    half_width = 4.303 * statistics.stdev(values) / math.sqrt(3)
    return mean, half_width


def linear_regression(x, y):
    x, y = list(map(float, x)), list(map(float, y))
    xm, ym = statistics.fmean(x), statistics.fmean(y)
    slope = sum((a-xm)*(b-ym) for a, b in zip(x, y)) / sum((a-xm)**2 for a in x)
    total = sum((b-ym)**2 for b in y)
    residual = sum((b-(ym+slope*(a-xm)))**2 for a, b in zip(x, y))
    return slope, 1-residual/total if total else 1.0


def interface_summary(frames):
    rows = []
    for replica, data in frames.items():
        data = sorted(data, key=lambda row: int(row['step']))
        fit = [r for r in data if 500 <= float(r['time_ps']) <= 4020]
        terminal = [r for r in data if 3020 <= float(r['time_ps']) <= 4020]
        if len(fit) != 705 or len(terminal) != 201:
            raise ValueError(f'{replica}: expected a complete 5 ps trajectory')
        for front in ('lower', 'upper'):
            slope, r2 = linear_regression([r['time_ps'] for r in fit], [r[f'{front}_x50_A'] for r in fit])
            velocity = (-1 if front == 'lower' else 1) * slope * 100
            widths = [float(r[f'{front}_width_A']) for r in terminal]
            rows.append(dict(replica=replica, front=front,
                final_advance_A=float(data[-1][f'{front}_advance_A']),
                velocity_m_per_s=velocity, velocity_fit_r2=r2,
                terminal_width_mean_A=statistics.fmean(widths),
                terminal_width_temporal_sd_A=statistics.stdev(widths)))
    return rows


def aligned_profiles(frames, structure):
    accum = {float(lo): defaultdict(float) for lo in range(-30, 30, 5)}
    for replica in REPLICAS:
        positions = {int(r['step']): r for r in frames[replica]
                     if 3020 <= float(r['time_ps']) <= 4020}
        selected_steps = set()
        for row in structure[replica]:
            step = int(row['step'])
            if step not in positions:
                continue
            selected_steps.add(step)
            frame = positions[step]
            z, count = float(row['z_center_A']), float(row['count'])
            values = dict(count=count, ordered_sum=count*float(row['ordered_fraction']),
                          q4_sum=count*float(row['mean_q4']), q6_sum=count*float(row['mean_q6']))
            values.update({f'{e}_count': float(row[e]) for e in ELEMENTS})
            for distance in (z-float(frame['lower_x50_A']), float(frame['upper_x50_A'])-z):
                if -30 <= distance < 30:
                    low = float(math.floor((distance+30)/5)*5-30)
                    for key, value in values.items():
                        accum[low][key] += value
        if len(selected_steps) != 101:
            raise ValueError(f'{replica}: expected 101 axial profiles sampled every 10 ps')
    output = []
    for low, values in accum.items():
        count = values['count']
        row = dict(bin_lo_A=low, bin_hi_A=low+5, bin_center_A=low+2.5,
                   count=count, ordered_fraction=values['ordered_sum']/count,
                   mean_q4=values['q4_sum']/count, mean_q6=values['q6_sum']/count)
        row.update({f'{e}_fraction': values[f'{e}_count']/count for e in ELEMENTS})
        output.append(row)
    return output


def local_summary(compositions):
    terminal, series = [], []
    for replica in REPLICAS:
        for r in compositions[replica]:
            if r['scope'] == 'combined' and int(r['step']) == 4020000:
                terminal.append(dict(replica=replica, element=r['element'],
                    x_solid=float(r['x_local_solid']), x_liquid=float(r['x_local_liquid']),
                    k_local=float(r['k_local'])))
            if r['scope'] == 'combined' and r['element'] == 'Mn' and 3020 <= float(r['time_ps']) <= 4020:
                series.append(dict(replica=replica, time_ps=float(r['time_ps']), k_local=float(r['k_local'])))
    ensemble=[]
    for e in ELEMENTS:
        mean, ci = mean_interval(r['k_local'] for r in terminal if r['element'] == e)
        ensemble.append(dict(element=e, k_mean=mean, ci95_half_width=ci, ci95_lower=mean-ci, ci95_upper=mean+ci))
    return terminal, ensemble, series


def regional_sro_summary(sro):
    groups=defaultdict(dict)
    for replica, rows in sro.items():
        for r in rows:
            if r['center_element'] != 'Mn':
                continue
            key=(float(r['time_ps']), r['region'].replace('seed_connected_solid','central_solid'), float(r['cutoff_A']), r['neighbor_element'])
            groups[key][replica]=float(r['alpha'])
    output=[]
    for (time, region, cutoff, neighbor), values in sorted(groups.items()):
        mean, ci=mean_interval(values.values())
        output.append(dict(time_ps=time, region=region, cutoff_A=cutoff, neighbor=neighbor,
                           alpha_mean=mean, ci95_half_width=ci))
    for time in (20.,1020.,2020.,3020.,4020.):
        for cutoff in (3.,3.2,3.5):
            for neighbor in ELEMENTS:
                values=[(groups[(time,'lower_liquid',cutoff,neighbor)][r]+
                         groups[(time,'upper_liquid',cutoff,neighbor)][r])/2 for r in REPLICAS]
                mean,ci=mean_interval(values)
                output.append(dict(time_ps=time,region='combined_liquid',cutoff_A=cutoff,
                                   neighbor=neighbor,alpha_mean=mean,ci95_half_width=ci))
    return output


def temperature_summary(paths):
    replicas=[]
    for path in paths:
        chunks=defaultdict(list)
        with path.open() as handle:
            lines=iter(handle)
            for line in lines:
                if not line.strip() or line.lstrip().startswith('#'):
                    continue
                step, n, _=line.split()
                for _ in range(int(n)):
                    values=next(lines).split()
                    if 3020000 <= int(step) <= 4020000:
                        chunks[(int(values[0]),float(values[1]))].append(float(values[-1]))
        replicas.append({k:statistics.fmean(v) for k,v in chunks.items()})
    rows=[]
    for (chunk, coordinate) in sorted(replicas[0]):
        mean,ci=mean_interval(r[(chunk,coordinate)] for r in replicas)
        rows.append(dict(chunk=chunk,z_reduced=coordinate,temperature_mean_K=mean,ci95_half_width_K=ci))
    return rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--input',type=Path,required=True,help='Analysis directory containing replica_01 through replica_03')
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--simulation-root',type=Path,help='Optional directory containing three temperature_profile.dat files')
    args=parser.parse_args(); args.out.mkdir(parents=True,exist_ok=True)
    load=lambda name:{r:read_csv(args.input/r/name) for r in REPLICAS}
    frames=load('interface_positions.csv')
    write_csv(args.out/'interface_migration.csv',interface_summary(frames))
    profile=aligned_profiles(frames,load('axial_structure.csv'))
    write_csv(args.out/'interface_aligned_profiles.csv',profile)
    terminal,ensemble,series=local_summary(load('local_composition.csv'))
    write_csv(args.out/'terminal_composition_by_replica.csv',terminal)
    write_csv(args.out/'terminal_composition_summary.csv',ensemble)
    write_csv(args.out/'mn_local_composition_time_series.csv',series)
    write_csv(args.out/'mn_regional_sro_summary.csv',regional_sro_summary(load('regional_sro.csv')))
    layers=[]
    for name,lows in [('liquid',(-15.,-10.)),('solid',(5.,10.))]:
        selected=[r for r in profile if r['bin_lo_A'] in lows]
        count=sum(r['count'] for r in selected)
        for e in ELEMENTS:
            fraction=sum(r['count']*r[f'{e}_fraction'] for r in selected)/count
            layers.append(dict(layer=name,element=e,atomic_percent=100*fraction))
    write_csv(args.out/'terminal_window_layer_composition.csv',layers)
    if args.simulation_root:
        paths=[args.simulation_root/r/'temperature_profile.dat' for r in REPLICAS]
        write_csv(args.out/'temperature_profile.csv',temperature_summary(paths))

if __name__=='__main__':
    main()
