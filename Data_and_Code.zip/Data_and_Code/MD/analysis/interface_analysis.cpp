// Interface geometry, local composition and phase-filtered Mn coordination.
#include <algorithm>
#include <cerrno>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <vector>

namespace {

const int ELEMENTS = 5;
const int DEFAULT_BINS = 160;
const char *ELEMENT_NAMES[ELEMENTS] = {"Co", "Cr", "Fe", "Mn", "Ni"};
const char *REQUIRED_ATOM_HEADER =
    "ITEM: ATOMS id type xu yu zu c_ptm[1] c_ptm[2] c_cna c_q46[1] c_q46[2] "
    "v_is_cold v_is_hot f_bath_contact[1] f_bath_contact[2]";

struct Config {
    std::string input, output, replica;
    int expected_atoms = 576000, bins = 160;
    int first_step = 0, last_step = 4020000, step_increment = 5000;
    std::set<int> sro_steps = {20000, 1020000, 2020000, 3020000, 4020000};
};

struct Bounds {
    double lo[3];
    double hi[3];
    double length(int axis) const { return hi[axis] - lo[axis]; }
};

struct InterfaceMetrics {
    double lower10;
    double lower50;
    double lower90;
    double upper90;
    double upper50;
    double upper10;
    double central_ordered;
    double lower_hot_ordered;
    double upper_hot_ordered;
    bool connected;
    InterfaceMetrics()
        : lower10(NAN), lower50(NAN), lower90(NAN), upper90(NAN),
          upper50(NAN), upper10(NAN), central_ordered(NAN),
          lower_hot_ordered(NAN), upper_hot_ordered(NAN), connected(false) {}
};

struct BinStats {
    long long count;
    long long ordered;
    long long ptm_fcc;
    long long ptm_hcp;
    long long cna[6];
    long long types[ELEMENTS];
    double q4_sum;
    double q6_sum;
    BinStats() : count(0), ordered(0), ptm_fcc(0), ptm_hcp(0), q4_sum(0), q6_sum(0) {
        std::fill(cna, cna + 6, 0);
        std::fill(types, types + ELEMENTS, 0);
    }
};

struct AtomLine {
    int id;
    int type;
    int ptm;
    int cna;
    double x;
    double y;
    double z;
    double q4;
    double q6;
};

void require(bool condition, const std::string &message) {
    if (!condition) throw std::runtime_error(message);
}

void ensure_directory(const std::string &path) {
    if (::mkdir(path.c_str(), 0755) != 0 && errno != EEXIST) {
        throw std::runtime_error("cannot create output directory: " + path);
    }
}

int parse_int_token(const char *&cursor) {
    while (*cursor == ' ' || *cursor == '\t') ++cursor;
    char *end = NULL;
    long value = std::strtol(cursor, &end, 10);
    if (end == cursor) throw std::runtime_error("malformed integer atom token");
    cursor = end;
    return static_cast<int>(value);
}

double parse_double_token(const char *&cursor) {
    while (*cursor == ' ' || *cursor == '\t') ++cursor;
    char *end = NULL;
    double value = std::strtod(cursor, &end);
    if (end == cursor || !std::isfinite(value)) {
        throw std::runtime_error("malformed or non-finite atom token");
    }
    cursor = end;
    return value;
}

void skip_token(const char *&cursor) {
    while (*cursor == ' ' || *cursor == '\t') ++cursor;
    if (*cursor == '\0') throw std::runtime_error("truncated atom line");
    while (*cursor && *cursor != ' ' && *cursor != '\t' && *cursor != '\r' && *cursor != '\n') ++cursor;
}

AtomLine parse_atom_line(const std::string &line, bool full) {
    const char *cursor = line.c_str();
    AtomLine atom;
    atom.id = parse_int_token(cursor);
    atom.type = parse_int_token(cursor);
    if (full) atom.x = parse_double_token(cursor); else { skip_token(cursor); atom.x = NAN; }
    if (full) atom.y = parse_double_token(cursor); else { skip_token(cursor); atom.y = NAN; }
    atom.z = parse_double_token(cursor);
    atom.ptm = parse_int_token(cursor);
    skip_token(cursor);
    if (full) {
        atom.cna = parse_int_token(cursor);
        atom.q4 = parse_double_token(cursor);
        atom.q6 = parse_double_token(cursor);
    } else {
        skip_token(cursor);
        skip_token(cursor);
        skip_token(cursor);
        atom.cna = 0;
        atom.q4 = NAN;
        atom.q6 = NAN;
    }
    return atom;
}

double wrap(double value, double lo, double hi) {
    const double length = hi - lo;
    double shifted = std::fmod(value - lo, length);
    if (shifted < 0) shifted += length;
    return lo + shifted;
}

double crossing_lower(const std::vector<double> &profile, double target, const Bounds &box) {
    const int center = static_cast<int>(profile.size()) / 2;
    for (int i = center; i > 0; --i) {
        if (profile[i] >= target && profile[i - 1] < target) {
            double a = profile[i - 1];
            double b = profile[i];
            double fraction = (target - a) / std::max(1.0e-12, b - a);
            double bin_position = (i - 0.5) + fraction;
            return box.lo[2] + box.length(2) * bin_position / profile.size();
        }
    }
    return NAN;
}

double crossing_upper(const std::vector<double> &profile, double target, const Bounds &box) {
    const int center = static_cast<int>(profile.size()) / 2;
    for (int i = center; i + 1 < static_cast<int>(profile.size()); ++i) {
        if (profile[i] >= target && profile[i + 1] < target) {
            double a = profile[i];
            double b = profile[i + 1];
            double fraction = (target - a) / std::min(-1.0e-12, b - a);
            double bin_position = (i + 0.5) + fraction;
            return box.lo[2] + box.length(2) * bin_position / profile.size();
        }
    }
    return NAN;
}

InterfaceMetrics compute_interfaces(const std::vector<BinStats> &bins, const Bounds &box) {
    InterfaceMetrics result;
    std::vector<double> raw(bins.size(), 0.0), smooth(bins.size(), 0.0);
    for (size_t i = 0; i < bins.size(); ++i) {
        if (bins[i].count == 0) throw std::runtime_error("empty z bin in interface profile");
        raw[i] = static_cast<double>(bins[i].ordered) / bins[i].count;
    }
    for (size_t i = 0; i < bins.size(); ++i) {
        size_t left = (i + bins.size() - 1) % bins.size();
        size_t right = (i + 1) % bins.size();
        smooth[i] = (raw[left] + raw[i] + raw[right]) / 3.0;
    }
    result.lower10 = crossing_lower(smooth, 0.10, box);
    result.lower50 = crossing_lower(smooth, 0.50, box);
    result.lower90 = crossing_lower(smooth, 0.90, box);
    result.upper90 = crossing_upper(smooth, 0.90, box);
    result.upper50 = crossing_upper(smooth, 0.50, box);
    result.upper10 = crossing_upper(smooth, 0.10, box);
    if (!std::isfinite(result.lower10) || !std::isfinite(result.lower50) ||
        !std::isfinite(result.lower90) || !std::isfinite(result.upper90) ||
        !std::isfinite(result.upper50) || !std::isfinite(result.upper10)) {
        throw std::runtime_error("paired interface crossing not resolved");
    }
    const int n = static_cast<int>(bins.size());
    int cold_lo = static_cast<int>(0.45 * n);
    int cold_hi = static_cast<int>(0.55 * n);
    int hot_n = std::max(1, static_cast<int>(0.05 * n));
    long long count = 0, ordered = 0;
    for (int i = cold_lo; i < cold_hi; ++i) { count += bins[i].count; ordered += bins[i].ordered; }
    result.central_ordered = static_cast<double>(ordered) / count;
    count = ordered = 0;
    for (int i = 0; i < hot_n; ++i) { count += bins[i].count; ordered += bins[i].ordered; }
    result.lower_hot_ordered = static_cast<double>(ordered) / count;
    count = ordered = 0;
    for (int i = n - hot_n; i < n; ++i) { count += bins[i].count; ordered += bins[i].ordered; }
    result.upper_hot_ordered = static_cast<double>(ordered) / count;
    int lower_bin = std::max(0, static_cast<int>((result.lower90 - box.lo[2]) / box.length(2) * n));
    int upper_bin = std::min(n - 1, static_cast<int>((result.upper90 - box.lo[2]) / box.length(2) * n));
    result.connected = true;
    for (int i = lower_bin; i <= upper_bin; ++i) {
        if (smooth[i] < 0.50) { result.connected = false; break; }
    }
    return result;
}

Config parse_args(int argc, char **argv) {
    Config c;
    for (int i = 1; i < argc; ++i) {
        std::string key(argv[i]);
        if (key == "--help") {
            std::cout << "interface_analysis --input FILE --out DIR --replica NAME "
                "[--first-step 0] [--last-step 4020000] [--expected-atoms 576000]\n";
            std::exit(0);
        }
        require(i + 1 < argc, "missing value for " + key);
        std::string v(argv[++i]);
        if (key == "--input") c.input = v;
        else if (key == "--out") c.output = v;
        else if (key == "--replica") c.replica = v;
        else if (key == "--first-step") c.first_step = std::stoi(v);
        else if (key == "--last-step") c.last_step = std::stoi(v);
        else if (key == "--expected-atoms") c.expected_atoms = std::stoi(v);
        else throw std::runtime_error("unknown argument: " + key);
    }
    require(!c.input.empty() && !c.output.empty() && !c.replica.empty(),
            "--input, --out and --replica are required");
    require(c.expected_atoms > 0 && c.first_step >= 0 && c.last_step >= c.first_step,
            "invalid atom count or step range");
    return c;
}

class Analyzer {
public:
    explicit Analyzer(const Config &config) : cfg(config), types(cfg.expected_atoms),
        x(cfg.expected_atoms), y(cfg.expected_atoms), zraw(cfg.expected_atoms),
        zwrap(cfg.expected_atoms), ordered(cfg.expected_atoms) {}
    void run() {
        ensure_directory(cfg.output);
        open_outputs();
        parse_trajectory();
    }
private:
    Config cfg;
    std::vector<unsigned char> types, ordered;
    std::vector<float> x, y, zraw, zwrap;
    std::ofstream frame_csv, partition_csv, structure_csv, sro_csv, track_csv;
    int frames = 0;
    Bounds initial_box;
    double initial_lower50 = NAN, initial_upper50 = NAN;
    std::string output_path(const std::string &name) const { return cfg.output + "/" + name; }
    void open_outputs() {
        frame_csv.open(output_path("interface_positions.csv"));
        partition_csv.open(output_path("local_composition.csv"));
        structure_csv.open(output_path("axial_structure.csv"));
        sro_csv.open(output_path("regional_sro.csv"));
        track_csv.open(output_path("mn_trajectories.csv"));
        require(frame_csv && partition_csv && structure_csv && sro_csv && track_csv,
                "cannot open output files");
        frame_csv << std::setprecision(12);
        partition_csv << std::setprecision(12);
        structure_csv << std::setprecision(12);
        sro_csv << std::setprecision(12);
        track_csv << std::setprecision(12);
        frame_csv << "replica,step,time_ps,lz_A,lower_x10_A,lower_x50_A,lower_x90_A,lower_width_A,"
            "upper_x90_A,upper_x50_A,upper_x10_A,upper_width_A,lower_advance_A,upper_advance_A,"
            "central_ordered_fraction,lower_hot_ordered_fraction,upper_hot_ordered_fraction,seed_connected\n";
        partition_csv << "replica,step,time_ps,scope,element,local_solid_count,local_liquid_count,"
            "x_local_solid,x_local_liquid,k_local\n";
        structure_csv << "replica,step,time_ps,bin,z_center_A,count,ordered_fraction,ptm_fcc_fraction,"
            "ptm_hcp_fraction,cna_fcc_fraction,cna_hcp_fraction,cna_bcc_fraction,"
            "cna_ico_fraction,cna_unknown_fraction,mean_q4,mean_q6,Co,Cr,Fe,Mn,Ni\n";
        sro_csv << "replica,step,time_ps,region,cutoff_A,center_element,neighbor_element,"
            "directed_neighbor_count,total_center_neighbors,conditional_probability,regional_fraction,alpha\n";
        track_csv << "replica,step,time_ps,id,type,xu,yu,zu,ptm,q4,q6,lower_x50_A,signed_distance_A\n";
    }
    void parse_trajectory() {
        std::ifstream input(cfg.input);
        require(input.good(), "cannot open trajectory");
        std::string line;
        int previous_step = cfg.first_step - cfg.step_increment;
        while (std::getline(input, line)) {
            if (line.empty()) continue;
            require(line == "ITEM: TIMESTEP", "missing timestep header");
            require(bool(std::getline(input, line)), "truncated timestep");
            int step = std::stoi(line);
            require(step == previous_step + cfg.step_increment, "non-contiguous timestep sequence");
            previous_step = step;
            require(bool(std::getline(input, line)) && line == "ITEM: NUMBER OF ATOMS", "missing atom-count header");
            require(bool(std::getline(input, line)), "truncated atom count");
            const int atom_count = std::stoi(line);
            require(atom_count == cfg.expected_atoms, "unexpected atom count");
            require(bool(std::getline(input, line)) && line == "ITEM: BOX BOUNDS pp pp pp", "expected an orthogonal periodic box");
            Bounds box;
            for (int axis = 0; axis < 3; ++axis) {
                require(bool(std::getline(input, line)), "truncated box bounds");
                std::stringstream values(line);
                values >> box.lo[axis] >> box.hi[axis];
                require(std::isfinite(box.lo[axis]) && std::isfinite(box.hi[axis]) && box.hi[axis] > box.lo[axis], "invalid box bounds");
            }
            if (frames == 0) initial_box = box;
            else for (int axis = 0; axis < 3; ++axis)
                require(std::fabs(box.lo[axis]-initial_box.lo[axis]) < 1e-6 &&
                    std::fabs(box.hi[axis]-initial_box.hi[axis]) < 1e-6, "production box changed");
            require(bool(std::getline(input, line)) && line == REQUIRED_ATOM_HEADER, "unexpected atom columns");
            const bool sample_structure = step % 10000 == 0 || cfg.sro_steps.count(step);
            const bool full = frames == 0 || sample_structure;
            std::vector<BinStats> bins(cfg.bins);
            std::vector<AtomLine> selected;
            int type_counts[ELEMENTS] = {0};
            for (int row = 0; row < atom_count; ++row) {
                require(bool(std::getline(input, line)), "truncated atom records");
                bool select = cfg.replica == "replica_01" &&
                    ((row + 1 == 56118 && step >= 1605000 && step <= 1755000) ||
                     (row + 1 == 73385 && step >= 1740000 && step <= 1860000) ||
                     (row + 1 == 119697 && step >= 1640000 && step <= 4020000));
                AtomLine atom = parse_atom_line(line, full || select);
                require(atom.id == row + 1, "atom IDs must be sorted and contiguous");
                require(atom.type >= 1 && atom.type <= ELEMENTS, "unexpected atom type");
                if (frames == 0) types[row] = static_cast<unsigned char>(atom.type);
                else require(types[row] == atom.type, "atom type changed for fixed ID");
                ++type_counts[atom.type-1];
                if (full) { x[row] = atom.x; y[row] = atom.y; zraw[row] = atom.z; }
                const double wz = wrap(atom.z, box.lo[2], box.hi[2]);
                zwrap[row] = static_cast<float>(wz);
                ordered[row] = atom.ptm == 1 || atom.ptm == 2;
                int bin = static_cast<int>((wz-box.lo[2])/box.length(2)*cfg.bins);
                if (bin == cfg.bins) --bin;
                require(bin >= 0 && bin < cfg.bins, "invalid axial bin");
                BinStats &s = bins[bin];
                ++s.count; ++s.types[atom.type-1];
                if (ordered[row]) ++s.ordered;
                if (atom.ptm == 1) ++s.ptm_fcc;
                if (atom.ptm == 2) ++s.ptm_hcp;
                if (sample_structure) {
                    const int code = atom.cna >= 1 && atom.cna <= 5 ? atom.cna : 5;
                    ++s.cna[code]; s.q4_sum += atom.q4; s.q6_sum += atom.q6;
                }
                if (select) { require(atom.type == 4, "selected atom is not Mn"); selected.push_back(atom); }
            }
            for (int e = 0; e < ELEMENTS; ++e)
                require(type_counts[e]*ELEMENTS == atom_count, "global equiatomic composition changed");
            InterfaceMetrics interface = compute_interfaces(bins, box);
            if (frames == 0) { initial_lower50 = interface.lower50; initial_upper50 = interface.upper50; }
            write_frame(step, box, interface, initial_lower50-interface.lower50, interface.upper50-initial_upper50);
            write_partition(step, interface);
            if (sample_structure) write_structure(step, box, bins);
            if (cfg.sro_steps.count(step)) write_sro(step, box, interface);
            for (const AtomLine &a : selected)
                track_csv << cfg.replica << ',' << step << ',' << step*0.001 << ',' << a.id << ',' << a.type << ','
                    << a.x << ',' << a.y << ',' << a.z << ',' << a.ptm << ',' << a.q4 << ',' << a.q6 << ','
                    << interface.lower50 << ',' << a.z-interface.lower50 << '\n';
            ++frames;
        }
        require(previous_step == cfg.last_step, "trajectory does not end at the requested step");
        require(frames == (cfg.last_step-cfg.first_step)/cfg.step_increment+1, "unexpected frame count");
    }


    void write_frame(int step, const Bounds &box, const InterfaceMetrics &interface,
                     double lower_advance, double upper_advance) {
        frame_csv << cfg.replica << ',' << step << ',' << step * 0.001 << ',' << box.length(2) << ','
                  << interface.lower10 << ',' << interface.lower50 << ',' << interface.lower90 << ','
                  << interface.lower90 - interface.lower10 << ',' << interface.upper90 << ','
                  << interface.upper50 << ',' << interface.upper10 << ','
                  << interface.upper10 - interface.upper90 << ',' << lower_advance << ',' << upper_advance << ','
                  << interface.central_ordered << ',' << interface.lower_hot_ordered << ','
                  << interface.upper_hot_ordered << ',' << (interface.connected ? 1 : 0) << '\n';
    }

    void write_partition(int step, const InterfaceMetrics &interface) {
        long long local_solid[3][ELEMENTS] = {{0}}, local_liquid[3][ELEMENTS] = {{0}};
        const double inner = 5.0, outer = 15.0;
        for (int index = 0; index < cfg.expected_atoms; ++index) {
            int element = types[index] - 1;
            double z = zwrap[index];
            if (z >= interface.lower50 + inner && z < interface.lower50 + outer) {
                ++local_solid[0][element]; ++local_solid[2][element];
            }
            if (z <= interface.lower50 - inner && z > interface.lower50 - outer) {
                ++local_liquid[0][element]; ++local_liquid[2][element];
            }
            if (z <= interface.upper50 - inner && z > interface.upper50 - outer) {
                ++local_solid[1][element]; ++local_solid[2][element];
            }
            if (z >= interface.upper50 + inner && z < interface.upper50 + outer) {
                ++local_liquid[1][element]; ++local_liquid[2][element];
            }
        }
        const char *scopes[3] = {"lower", "upper", "combined"};
        for (int scope = 0; scope < 3; ++scope) {
            long long total_solid = 0, total_liquid = 0;
            for (int e = 0; e < ELEMENTS; ++e) { total_solid += local_solid[scope][e]; total_liquid += local_liquid[scope][e]; }
            require(total_solid > 0 && total_liquid > 0, "empty local composition layer");
            for (int e = 0; e < ELEMENTS; ++e) {
                const double xs = static_cast<double>(local_solid[scope][e])/total_solid;
                const double xl = static_cast<double>(local_liquid[scope][e])/total_liquid;
                partition_csv << cfg.replica << ',' << step << ',' << step*0.001 << ',' << scopes[scope] << ','
                    << ELEMENT_NAMES[e] << ',' << local_solid[scope][e] << ',' << local_liquid[scope][e] << ','
                    << xs << ',' << xl << ',' << (xl > 0 ? xs/xl : NAN) << '\n';
            }
        }
    }


    void write_structure(int step, const Bounds &box, const std::vector<BinStats> &bins) {
        for (int bin = 0; bin < cfg.bins; ++bin) {
            const BinStats &s = bins[bin];
            double count = static_cast<double>(s.count);
            structure_csv << cfg.replica << ',' << step << ',' << step * 0.001 << ',' << bin << ','
                          << box.lo[2] + (bin + 0.5) * box.length(2) / cfg.bins << ',' << s.count << ','
                          << s.ordered / count << ',' << s.ptm_fcc / count << ',' << s.ptm_hcp / count;
            for (int code = 1; code <= 5; ++code) structure_csv << ',' << s.cna[code] / count;
            structure_csv << ',' << s.q4_sum / count << ',' << s.q6_sum / count;
            for (int e = 0; e < ELEMENTS; ++e) structure_csv << ',' << s.types[e];
            structure_csv << '\n';
        }
    }

    void write_sro(int step, const Bounds &box, const InterfaceMetrics &interface) {
        const double cutoffs[3] = {3.0, 3.2, 3.5};
        const double maxcut = cutoffs[2];
        int nc[3];
        for (int axis = 0; axis < 3; ++axis) nc[axis] = std::max(1, static_cast<int>(box.length(axis) / maxcut));
        const int cell_count = nc[0] * nc[1] * nc[2];
        std::vector<int> head(cell_count, -1), next(cfg.expected_atoms, -1);
        std::vector<signed char> region(cfg.expected_atoms, -1);
        long long region_types[3][ELEMENTS] = {{0}};
        for (int i = 0; i < cfg.expected_atoms; ++i) {
            double wz = wrap(zraw[i], box.lo[2], box.hi[2]);
            if (ordered[i] && wz > interface.lower90 + 5.0 && wz < interface.upper90 - 5.0) region[i] = 0;
            else if (!ordered[i] && wz > box.lo[2] + 5.0 &&
                     wz < interface.lower10 - 5.0) region[i] = 1;
            else if (!ordered[i] && wz > interface.upper10 + 5.0 &&
                     wz < box.hi[2] - 5.0) region[i] = 2;
            if (region[i] >= 0) ++region_types[region[i]][types[i] - 1];
            double wrapped[3] = {wrap(x[i], box.lo[0], box.hi[0]), wrap(y[i], box.lo[1], box.hi[1]), wz};
            int index[3];
            for (int axis = 0; axis < 3; ++axis) {
                index[axis] = std::min(nc[axis] - 1, static_cast<int>((wrapped[axis] - box.lo[axis]) / box.length(axis) * nc[axis]));
            }
            int cell = (index[2] * nc[1] + index[1]) * nc[0] + index[0];
            next[i] = head[cell]; head[cell] = i;
        }
        long long directed[3][3][ELEMENTS][ELEMENTS] = {{{{0}}}};
        for (int i = 0; i < cfg.expected_atoms; ++i) {
            if (region[i] < 0) continue;
            double wi[3] = {wrap(x[i], box.lo[0], box.hi[0]), wrap(y[i], box.lo[1], box.hi[1]), wrap(zraw[i], box.lo[2], box.hi[2])};
            int ci[3];
            for (int axis = 0; axis < 3; ++axis) ci[axis] = std::min(nc[axis] - 1, static_cast<int>((wi[axis] - box.lo[axis]) / box.length(axis) * nc[axis]));
            for (int dz = -1; dz <= 1; ++dz) for (int dy = -1; dy <= 1; ++dy) for (int dx = -1; dx <= 1; ++dx) {
                int cx = (ci[0] + dx + nc[0]) % nc[0];
                int cy = (ci[1] + dy + nc[1]) % nc[1];
                int cz = (ci[2] + dz + nc[2]) % nc[2];
                int cell = (cz * nc[1] + cy) * nc[0] + cx;
                for (int j = head[cell]; j >= 0; j = next[j]) {
                    if (j <= i || region[j] != region[i]) continue;
                    double wj[3] = {wrap(x[j], box.lo[0], box.hi[0]), wrap(y[j], box.lo[1], box.hi[1]), wrap(zraw[j], box.lo[2], box.hi[2])};
                    double r2 = 0.0;
                    for (int axis = 0; axis < 3; ++axis) {
                        double delta = wj[axis] - wi[axis];
                        if (delta > 0.5 * box.length(axis)) delta -= box.length(axis);
                        if (delta < -0.5 * box.length(axis)) delta += box.length(axis);
                        r2 += delta * delta;
                    }
                    for (int cutoff = 0; cutoff < 3; ++cutoff) if (r2 <= cutoffs[cutoff] * cutoffs[cutoff]) {
                        int a = types[i] - 1, b = types[j] - 1, reg = region[i];
                        ++directed[cutoff][reg][a][b];
                        ++directed[cutoff][reg][b][a];
                    }
                }
            }
        }
        const char *regions[3] = {"central_solid", "lower_liquid", "upper_liquid"};
        for (int cutoff = 0; cutoff < 3; ++cutoff) for (int reg = 0; reg < 3; ++reg) {
            long long region_total = 0;
            for (int e = 0; e < ELEMENTS; ++e) region_total += region_types[reg][e];
            for (int a = 3; a < 4; ++a) {
                long long total_neighbors = 0;
                for (int b = 0; b < ELEMENTS; ++b) total_neighbors += directed[cutoff][reg][a][b];
                for (int b = 0; b < ELEMENTS; ++b) {
                    double p = total_neighbors ? static_cast<double>(directed[cutoff][reg][a][b]) / total_neighbors : NAN;
                    double c = region_total ? static_cast<double>(region_types[reg][b]) / region_total : NAN;
                    double alpha = std::isfinite(p) && c > 0 ? 1.0 - p / c : NAN;
                    sro_csv << cfg.replica << ',' << step << ',' << step * 0.001 << ',' << regions[reg] << ','
                            << cutoffs[cutoff] << ',' << ELEMENT_NAMES[a] << ',' << ELEMENT_NAMES[b] << ','
                            << directed[cutoff][reg][a][b] << ',' << total_neighbors << ',' << p << ',' << c << ',' << alpha << '\n';
                }
            }
        }
    }
};
}  // namespace

int main(int argc, char **argv) {
    try { Analyzer(parse_args(argc, argv)).run(); return 0; }
    catch (const std::exception &e) { std::cerr << e.what() << '\n'; return 1; }
}
