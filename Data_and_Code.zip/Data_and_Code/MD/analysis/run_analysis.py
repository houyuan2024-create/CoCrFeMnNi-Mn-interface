#!/usr/bin/env python3
"""Compile and run the interface analysis on the three production trajectories."""
import argparse
from pathlib import Path
import subprocess
import sys


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--simulation-root',type=Path,required=True)
    parser.add_argument('--out',type=Path,required=True)
    parser.add_argument('--compiler',default='c++')
    args=parser.parse_args()
    source=Path(__file__).resolve().parent
    args.out.mkdir(parents=True,exist_ok=True)
    binary=(args.out/'interface_analysis').resolve()
    subprocess.run([args.compiler,'-O3','-std=c++17',str(source/'interface_analysis.cpp'),'-o',str(binary)],check=True)
    for i in (1,2,3):
        replica=f'replica_{i:02d}'
        subprocess.run([str(binary),'--input',str(args.simulation_root/replica/'solidification.lammpstrj'),
                        '--out',str(args.out/replica),'--replica',replica],check=True)
    subprocess.run([sys.executable,str(source/'summarize_interfaces.py'),'--input',str(args.out),
                    '--out',str(args.out/'summary'),'--simulation-root',str(args.simulation_root)],check=True)

if __name__=='__main__':
    main()
