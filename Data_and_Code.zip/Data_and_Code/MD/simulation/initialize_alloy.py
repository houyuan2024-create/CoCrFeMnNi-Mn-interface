#!/usr/bin/env python3

"""Generate deterministic, slab-balanced CoCrFeMnNi FCC input data.

Chemical assignments use SplitMix64 and a Fisher-Yates shuffle independently
for each replica and each FCC layer along z.
"""

import argparse
from collections import Counter
from decimal import Decimal
import hashlib
import io
import json
import os
import sys


NX = 30
NY = 30
NZ = 160
LATTICE_A = Decimal("3.595")
ELEMENTS = ("Co", "Cr", "Fe", "Mn", "Ni")
MASSES = (
    Decimal("58.933194"),
    Decimal("51.9961"),
    Decimal("55.845"),
    Decimal("54.938044"),
    Decimal("58.6934"),
)
BASIS = (
    (Decimal("0"), Decimal("0"), Decimal("0")),
    (Decimal("0"), Decimal("0.5"), Decimal("0.5")),
    (Decimal("0.5"), Decimal("0"), Decimal("0.5")),
    (Decimal("0.5"), Decimal("0.5"), Decimal("0")),
)
ATOMS_PER_Z_CELL = 4 * NX * NY
ATOMS_PER_ELEMENT_PER_Z_CELL = ATOMS_PER_Z_CELL // len(ELEMENTS)
TOTAL_ATOMS = ATOMS_PER_Z_CELL * NZ
LOWER_STOP_CELL = 48
SEED_STOP_CELL = 112
UINT64_MASK = (1 << 64) - 1
BASE_CHEMICAL_SEED = 2026081101
try:
    TEXT_TYPE = unicode
except NameError:
    TEXT_TYPE = str


def splitmix64_next(state):
    state = (state + 0x9E3779B97F4A7C15) & UINT64_MASK
    value = state
    value = ((value ^ (value >> 30)) * 0xBF58476D1CE4E5B9) & UINT64_MASK
    value = ((value ^ (value >> 27)) * 0x94D049BB133111EB) & UINT64_MASK
    value ^= value >> 31
    return value & UINT64_MASK, state


def deterministic_shuffle(values, seed):
    state = seed & UINT64_MASK
    for index in range(len(values) - 1, 0, -1):
        value, state = splitmix64_next(state)
        swap_index = value % (index + 1)
        values[index], values[swap_index] = values[swap_index], values[index]


def slab_types(replicate, iz):
    values = []
    for type_id in range(1, len(ELEMENTS) + 1):
        values.extend([type_id] * ATOMS_PER_ELEMENT_PER_Z_CELL)
    seed = (
        BASE_CHEMICAL_SEED
        ^ (replicate * 0xD1B54A32D192ED03)
        ^ (iz * 0x94D049BB133111EB)
    ) & UINT64_MASK
    deterministic_shuffle(values, seed)
    return values


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def region_name(iz):
    if iz < LOWER_STOP_CELL:
        return "lower_liquid"
    if iz < SEED_STOP_CELL:
        return "crystal_seed"
    return "upper_liquid"


def self_test():
    assert ATOMS_PER_Z_CELL % len(ELEMENTS) == 0
    assert TOTAL_ATOMS == 576000
    expected = Counter(
        dict((type_id, ATOMS_PER_ELEMENT_PER_Z_CELL) for type_id in range(1, 6))
    )
    for replicate in (1, 2, 3):
        for iz in range(NZ):
            assert Counter(slab_types(replicate, iz)) == expected


def generate(output, replicate):
    if replicate not in (1, 2, 3):
        raise ValueError("replicate must be 1, 2, or 3")
    output = os.path.abspath(output)
    parent = os.path.dirname(output)
    metadata_path = os.path.join(parent, "initial_structure.json")
    if os.path.exists(output) or os.path.exists(metadata_path):
        raise IOError("refusing to overwrite an existing initial state")
    if not os.path.isdir(parent):
        os.makedirs(parent)
    partial = output + ".partial"
    if os.path.exists(partial):
        raise IOError("partial output already exists: {0}".format(partial))

    lx = Decimal(NX) * LATTICE_A
    ly = Decimal(NY) * LATTICE_A
    lz = Decimal(NZ) * LATTICE_A
    global_counts = Counter()
    regional_counts = dict(
        (name, Counter())
        for name in ("lower_liquid", "crystal_seed", "upper_liquid")
    )

    with io.open(partial, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(u"Equiatomic CoCrFeMnNi FCC crystal\n")
        handle.write(
            u"# replicate={0} chemical_seed={1}\n\n".format(
                replicate, BASE_CHEMICAL_SEED
            )
        )
        handle.write(u"{0} atoms\n5 atom types\n\n".format(TOTAL_ATOMS))
        handle.write(u"0.000000000000 {0:.12f} xlo xhi\n".format(lx))
        handle.write(u"0.000000000000 {0:.12f} ylo yhi\n".format(ly))
        handle.write(u"0.000000000000 {0:.12f} zlo zhi\n\n".format(lz))
        handle.write(u"Masses\n\n")
        for type_id, item in enumerate(zip(ELEMENTS, MASSES), start=1):
            element, mass = item
            handle.write(u"{0} {1} # {2}\n".format(type_id, mass, element))
        handle.write(u"\nAtoms # atomic\n\n")

        atom_id = 0
        for iz in range(NZ):
            types = slab_types(replicate, iz)
            counts = Counter(types)
            global_counts.update(counts)
            regional_counts[region_name(iz)].update(counts)
            local_index = 0
            for iy in range(NY):
                for ix in range(NX):
                    for bx, by, bz in BASIS:
                        atom_id += 1
                        type_id = types[local_index]
                        local_index += 1
                        x = (Decimal(ix) + bx) * LATTICE_A
                        y = (Decimal(iy) + by) * LATTICE_A
                        z = (Decimal(iz) + bz) * LATTICE_A
                        handle.write(
                            u"{0} {1} {2:.12f} {3:.12f} {4:.12f}\n".format(
                                atom_id, type_id, x, y, z
                            )
                        )

    if atom_id != TOTAL_ATOMS:
        raise RuntimeError("atom-count invariant failed")
    expected_global = Counter(
        dict((type_id, TOTAL_ATOMS // 5) for type_id in range(1, 6))
    )
    if global_counts != expected_global:
        raise RuntimeError("global composition invariant failed")
    os.rename(partial, output)

    metadata = {
        "schema_version": 1,
        "python_runtime": sys.version.split()[0],
        "replicate": replicate,
        "chemical_seed_base": BASE_CHEMICAL_SEED,
        "cells": [NX, NY, NZ],
        "lattice_constant_angstrom": float(LATTICE_A),
        "total_atoms": TOTAL_ATOMS,
        "atoms_per_z_cell": ATOMS_PER_Z_CELL,
        "per_z_cell_type_counts": dict(
            (element, ATOMS_PER_ELEMENT_PER_Z_CELL) for element in ELEMENTS
        ),
        "type_map": dict(
            (str(index), element) for index, element in enumerate(ELEMENTS, 1)
        ),
        "global_type_counts": dict(
            (str(key), value) for key, value in sorted(global_counts.items())
        ),
        "regional_type_counts": dict(
            (
                name,
                dict((str(key), value) for key, value in sorted(counts.items())),
            )
            for name, counts in regional_counts.items()
        ),
        "region_id_ranges": {
            "lower_liquid": [1, 172800],
            "crystal_seed": [172801, 403200],
            "upper_liquid": [403201, 576000],
        },
        "data_file": os.path.basename(output),
        "data_file_sha256": sha256(output),
    }
    with io.open(metadata_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(TEXT_TYPE(json.dumps(metadata, indent=2, sort_keys=True)))
        handle.write(u"\n")
    return metadata


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--replica", "--replicate", dest="replicate", type=int)
    parser.add_argument("--output")
    parser.add_argument("--self-test", action="store_true")
    args = parser.parse_args()
    if args.self_test:
        self_test()
        print("SELF_TEST_PASS")
        return 0
    if args.replicate is None or args.output is None:
        parser.error("--replica and --output are required unless --self-test is used")
    metadata = generate(args.output, args.replicate)
    print(json.dumps(metadata, sort_keys=True))
    return 0


if __name__ == "__main__":
    sys.exit(main())
