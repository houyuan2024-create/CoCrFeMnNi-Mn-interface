#!/usr/bin/env python3
"""Generate and run one of the three CoCrFeMnNi solidification replicas."""

import argparse
import csv
import json
from pathlib import Path
import shlex
import subprocess
import sys

from initialize_alloy import generate
from check_interface import evaluate


HERE = Path(__file__).resolve().parent


def parameters(replica):
    with (HERE / "replica_parameters.csv").open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    return next({key: int(value) for key, value in row.items()}
                for row in rows if int(row["replica"]) == replica)


def run_stage(command, input_name, output, seeds):
    args = command + ["-log", "none", "-in", str(HERE / input_name),
                      "-var", "run_dir", str(output),
                      "-var", "potential_dir", str(HERE.parent / "potentials")]
    for name, value in seeds.items():
        args.extend(["-var", name, str(value)])
    subprocess.run(args, cwd=output, check=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replica", type=int, choices=(1, 2, 3), required=True)
    parser.add_argument("--lammps", default="lmp",
                        help='LAMMPS command, for example "mpirun -np 96 lmp_mpi"')
    parser.add_argument("--output", type=Path,
                        help="New replica directory; defaults to ./replica_01, 02 or 03")
    parser.add_argument("--initialize-only", action="store_true",
                        help="Generate the initial FCC crystal without running LAMMPS")
    args = parser.parse_args()
    output = (args.output or Path("replica_{:02d}".format(args.replica))).resolve()
    if output.exists():
        parser.error("output directory already exists: {}".format(output))
    command = shlex.split(args.lammps)
    if not command:
        parser.error("--lammps must specify an executable")
    seeds = parameters(args.replica)
    output.mkdir(parents=True)
    generate(str(output / "initial_crystal.data"), args.replica)
    if args.initialize_only:
        print("Initial crystal written to {}".format(output))
        return 0
    run_stage(command, "prepare_interface.lmp", output,
              {name: seeds[name] for name in ("solid_seed", "liquid_seed", "release_seed")})
    report, status = evaluate(str(output))
    (output / "initial_interface_check.json").write_text(json.dumps(report, indent=2) + "\n")
    if status:
        print(json.dumps(report, indent=2), file=sys.stderr)
        return status
    run_stage(command, "solidify_interface.lmp", output,
              {name: seeds[name] for name in ("cold_seed", "hot_seed")})
    return 0


if __name__ == "__main__":
    sys.exit(main())
