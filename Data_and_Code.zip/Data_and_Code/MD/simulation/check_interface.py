#!/usr/bin/env python3

"""Check atom counts, composition and PTM order after interface preparation."""

import argparse
from collections import Counter
import hashlib
import io
import json
import math
import os
import re
import sys


TOTAL_ATOMS = 576000
REGIONS = {
    "lower_liquid": (1, 172800),
    "crystal_seed": (172801, 403200),
    "upper_liquid": (403201, 576000),
}
SOLID_CODES = set([1, 2])
try:
    TEXT_TYPE = unicode
except NameError:
    TEXT_TYPE = str


def is_finite(value):
    return not (math.isinf(value) or math.isnan(value))


def sha256(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        while True:
            chunk = handle.read(1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def parse_dump(path):
    with io.open(path, "r", encoding="utf-8") as handle:
        if handle.readline().strip() != "ITEM: TIMESTEP":
            raise ValueError("missing TIMESTEP header")
        timestep = int(handle.readline())
        if handle.readline().strip() != "ITEM: NUMBER OF ATOMS":
            raise ValueError("missing NUMBER OF ATOMS header")
        natoms = int(handle.readline())
        bounds_header = handle.readline().strip()
        if not bounds_header.startswith("ITEM: BOX BOUNDS"):
            raise ValueError("missing BOX BOUNDS header")
        bounds = []
        for unused in range(3):
            values = handle.readline().split()[:2]
            bounds.append(tuple(float(value) for value in values))
        atoms_header = handle.readline().strip().split()
        if atoms_header[:2] != ["ITEM:", "ATOMS"]:
            raise ValueError("missing ATOMS header")
        columns = atoms_header[2:]
        required = set(["id", "type", "c_prep_ptm[1]"])
        if not required.issubset(set(columns)):
            raise ValueError(
                "missing columns: {0}".format(sorted(required - set(columns)))
            )
        id_col = columns.index("id")
        type_col = columns.index("type")
        ptm_col = columns.index("c_prep_ptm[1]")

        global_types = Counter()
        region_types = dict((name, Counter()) for name in REGIONS)
        region_ordered = Counter()
        region_counts = Counter()
        ids_contiguous = True
        for row_index in range(natoms):
            fields = handle.readline().split()
            if len(fields) != len(columns):
                raise ValueError("truncated or malformed atom line")
            atom_id = int(fields[id_col])
            atom_type = int(fields[type_col])
            ptm = int(float(fields[ptm_col]))
            if atom_id != row_index + 1:
                ids_contiguous = False
            global_types[atom_type] += 1
            if 1 <= atom_id <= 172800:
                name = "lower_liquid"
            elif 172801 <= atom_id <= 403200:
                name = "crystal_seed"
            elif 403201 <= atom_id <= 576000:
                name = "upper_liquid"
            else:
                raise ValueError("atom ID outside the expected range: {0}".format(atom_id))
            region_counts[name] += 1
            region_types[name][atom_type] += 1
            region_ordered[name] += int(ptm in SOLID_CODES)
        if handle.readline():
            raise ValueError("unexpected data after single-frame dump")

    fractions = dict(
        (name, float(region_ordered[name]) / region_counts[name]) for name in REGIONS
    )
    return {
        "timestep": timestep,
        "natoms": natoms,
        "bounds": bounds,
        "ids_contiguous": ids_contiguous and natoms == TOTAL_ATOMS,
        "global_type_counts": dict(sorted(global_types.items())),
        "regional_type_counts": dict(
            (name, dict(sorted(counts.items())))
            for name, counts in region_types.items()
        ),
        "ordered_fractions": fractions,
    }


def evaluate(run_dir):
    failures = []
    required_names = [
        "preparation.log",
        "initial_interface.lammpstrj",
        "initial_interface.data",
        "initial_interface.restart",
        "melted.restart",
    ]
    required_files = [os.path.join(run_dir, name) for name in required_names]
    for path in required_files:
        if not os.path.isfile(path) or os.path.getsize(path) == 0:
            failures.append("missing or empty: {0}".format(os.path.basename(path)))

    metrics = {}
    if not failures:
        metrics = parse_dump(os.path.join(run_dir, "initial_interface.lammpstrj"))
        if metrics["natoms"] != TOTAL_ATOMS:
            failures.append("atom count changed")
        if not metrics["ids_contiguous"]:
            failures.append("sorted atom IDs are not contiguous")
        expected_global = dict((index, 115200) for index in range(1, 6))
        if metrics["global_type_counts"] != expected_global:
            failures.append("global composition changed")
        expected_region = {
            "lower_liquid": dict((index, 34560) for index in range(1, 6)),
            "crystal_seed": dict((index, 46080) for index in range(1, 6)),
            "upper_liquid": dict((index, 34560) for index in range(1, 6)),
        }
        if metrics["regional_type_counts"] != expected_region:
            failures.append("regional composition changed")
        fractions = metrics["ordered_fractions"]
        seed_fraction = float(fractions["crystal_seed"])
        if not is_finite(seed_fraction):
            failures.append("crystal_seed ordered fraction is non-finite")
        elif seed_fraction < 0.70:
            failures.append("crystal_seed PTM(FCC+HCP) fraction < 0.70")
        for name in ("lower_liquid", "upper_liquid"):
            value = float(fractions[name])
            if not is_finite(value):
                failures.append("{0} ordered fraction is non-finite".format(name))
            elif value > 0.20:
                failures.append("{0} PTM(FCC+HCP) fraction > 0.20".format(name))

        with io.open(
            os.path.join(run_dir, "preparation.log"), "r", encoding="utf-8", errors="replace"
        ) as handle:
            log_text = handle.read()
        if "ERROR:" in log_text:
            failures.append("LAMMPS ERROR found in preparation.log")
        if re.search(r"Lost atoms", log_text, flags=re.IGNORECASE):
            failures.append("lost-atoms message found in preparation.log")
        if "Total wall time:" not in log_text:
            failures.append("preparation.log lacks terminal Total wall time")

    hashes = {}
    for path in required_files:
        if os.path.isfile(path):
            hashes[os.path.basename(path)] = sha256(path)
    report = {
        "schema_version": 1,
        "check": "initial_interface_structure",
        "status": "PASS" if not failures else "FAIL",
        "python_runtime": sys.version.split()[0],
        "thresholds": {
            "solid_ptm_codes": [1, 2],
            "crystal_seed_ordered_fraction_min": 0.70,
            "each_liquid_ordered_fraction_max": 0.20,
        },
        "metrics": metrics,
        "failures": failures,
        "hashes": hashes,
    }
    return report, 0 if not failures else 2


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", required=True)
    args = parser.parse_args()
    run_dir = os.path.abspath(args.run_dir)
    report_path = os.path.join(run_dir, "initial_interface_check.json")
    try:
        report, return_code = evaluate(run_dir)
    except Exception as exc:
        report = {
            "schema_version": 1,
            "check": "initial_interface_structure",
            "status": "FAIL",
            "python_runtime": sys.version.split()[0],
            "failures": ["{0}: {1}".format(type(exc).__name__, exc)],
        }
        return_code = 2
    with io.open(report_path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(TEXT_TYPE(json.dumps(report, indent=2, sort_keys=True)))
        handle.write(u"\n")
    print(json.dumps(report, sort_keys=True))
    return return_code


if __name__ == "__main__":
    sys.exit(main())
