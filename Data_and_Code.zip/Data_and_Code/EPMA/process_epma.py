"""Response-normalized EPMA composition and chemical-region contrasts."""
from __future__ import annotations
import argparse
import csv
from dataclasses import dataclass
from datetime import datetime
import json
import math
from pathlib import Path
import re
from typing import Any, Iterable, Sequence
import numpy as np
from scipy import stats

ELEMENTS = ("Co", "Cr", "Fe", "Mn", "Ni")
CORE_ORIENTATION = {"Co": 1.0, "Cr": 1.0, "Fe": 1.0, "Mn": -1.0, "Ni": -1.0}


def load_count_map(path: str | Path) -> np.ndarray:
    values = np.genfromtxt(path, delimiter=',', encoding='utf-8-sig')
    if values.ndim != 2 or values.size == 0:
        raise ValueError(f'EPMA map is not a non-empty 2-D matrix: {path}')
    if not np.isfinite(values).all():
        raise ValueError(f'EPMA map contains non-finite values: {path}')
    if (values < 0).any():
        raise ValueError(f'EPMA count map contains negative values: {path}')
    return values

def _number(text: str, pattern: str) -> float | None:
    match = re.search(pattern, text, re.MULTILINE)
    return float(match.group(1)) if match else None

def _integers(text: str, pattern: str) -> tuple[int, int] | None:
    match = re.search(pattern, text, re.MULTILINE)
    return (int(match.group(1)), int(match.group(2))) if match else None

def parse_acquisition_param(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    text = path.read_text(encoding='utf-8', errors='replace')
    project_match = re.search('^Project:\\s*(.*?)\\s*$', text, re.MULTILINE)
    date_match = re.search('^(\\d{1,2}/\\d{1,2}/\\d{4}\\s+\\d{1,2}:\\d{2}:\\d{2}\\s+[AP]M)\\s*$', text, re.MULTILINE)
    direction_match = re.search('^Direction:\\s*(.*?)\\s*$', text, re.MULTILINE)
    points = _integers(text, '^Points\\s+(\\d+)\\s+X\\s+(\\d+)\\s*$')
    result: dict[str, Any] = {'param_path': str(path), 'project': project_match.group(1) if project_match else None, 'acquired_at': date_match.group(1) if date_match else None, 'accelerating_voltage_kv': _number(text, '^Acc\\.\\s*V\\s+([0-9.eE+-]+)\\s+kV'), 'probe_current_a': _number(text, '^Prob\\s+C\\s+([0-9.eE+-]+)A'), 'probe_diameter_um': _number(text, '^Prob\\s+Diam\\.\\s+([0-9.eE+-]+)'), 'dwell_ms': _number(text, '^Dwell\\(ms\\)\\s+([0-9.eE+-]+)'), 'stage_x_mm': _number(text, '^\\s*X\\s*:\\s*([0-9.eE+-]+)\\s+mm'), 'stage_y_mm': _number(text, '^\\s*Y\\s*:\\s*([0-9.eE+-]+)\\s+mm'), 'stage_z_mm': _number(text, '^\\s*Z\\s*:\\s*([0-9.eE+-]+)\\s+mm'), 'scan_direction': direction_match.group(1) if direction_match else None, 'points_x': points[0] if points else None, 'points_y': points[1] if points else None, 'pixel_size_x_um': _number(text, '^Interval\\(µm\\)\\s+X:([0-9.eE+-]+)'), 'pixel_size_y_um': _number(text, '^\\s*Y:([0-9.eE+-]+)\\s*$'), 'field_x_um': _number(text, '^Length\\s+\\(µm\\)\\s+X:([0-9.eE+-]+)'), 'field_y_um': None}
    length_block = re.search('^Length\\s+\\(µm\\)\\s+X:[^\\n]*\\n\\s*Y:([0-9.eE+-]+)', text, re.MULTILINE)
    if length_block:
        result['field_y_um'] = float(length_block.group(1))
    return result

def _regex_value(text: str, pattern: str, cast: Any=float) -> Any:
    match = re.search(pattern, text, re.MULTILINE)
    return cast(match.group(1)) if match else None

def parse_cnd_scan_metadata(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    text = path.read_text(encoding='utf-8', errors='replace')
    time_text = _regex_value(text, '^\\$XM_ANALYSIS_ACQ_DATE\\s+(.+?)\\s*$', str)
    timestamp = datetime.strptime(time_text, '%Y/%m/%d %H:%M:%S') if time_text else None
    pixels_match = re.search('^\\$XM_AP_SA_PIXELS%0\\s+(\\d+)\\s+(\\d+)\\s*$', text, re.MULTILINE)
    pixel_size_match = re.search('^\\$XM_AP_SA_PIXEL_SIZE%0\\s+([0-9.eE+-]+)\\s+([0-9.eE+-]+)\\s+([0-9.eE+-]+)\\s*$', text, re.MULTILINE)
    vertices = []
    for match in re.finditer('^\\$XM_AP_SA_STAGE_POS%0_(\\d+)\\s+([0-9.eE+-]+)\\s+([0-9.eE+-]+)\\s+([0-9.eE+-]+)\\s*$', text, re.MULTILINE):
        vertices.append((int(match.group(1)), float(match.group(2)), float(match.group(3)), float(match.group(4))))
    vertices.sort()
    return {'path': str(path), 'timestamp': timestamp, 'timestamp_text': time_text, 'pixels': (int(pixels_match.group(1)), int(pixels_match.group(2))) if pixels_match else None, 'pixel_size': tuple((float(pixel_size_match.group(index)) for index in range(1, 4))) if pixel_size_match else None, 'dwell_ms': _regex_value(text, '^\\$XM_AP_SA_DWELL_TIME%0\\s+([0-9.eE+-]+)\\s*$'), 'scan_direction': _regex_value(text, '^\\$XM_AP_SA_SCAN_DIRECTION%0\\s+(-?\\d+)\\s*$', int), 'scan_mode': _regex_value(text, '^\\$XM_AP_SA_SCAN_MODE%0\\s+(-?\\d+)\\s*$', int), 'rotation_angle': _regex_value(text, '^\\$XM_AP_SA_ROTATION_ANGLE%0\\s+([0-9.eE+-]+)\\s*$'), 'line_direction': _regex_value(text, '^\\$XM_AP_SA_LINE_DIRECTION%0\\s+(-?\\d+)\\s*$', int), 'stage_vertices': tuple(vertices)}

def _geometry_signature(metadata: dict[str, Any]) -> tuple[Any, ...]:
    return (metadata['pixels'], metadata['pixel_size'], metadata['dwell_ms'], metadata['scan_direction'], metadata['scan_mode'], metadata['rotation_angle'], metadata['line_direction'], metadata['stage_vertices'])

def verify_eds_wdsa_colocation(csv_dir: str | Path, *, time_tolerance_seconds: float=30.0) -> dict[str, Any]:
    csv_dir = Path(csv_dir)
    reference_path = csv_dir / 'metadata/BED_C.cnd'
    eds_paths = sorted((csv_dir / 'metadata').glob('*_Kalpha.cnd'))
    if not reference_path.is_file() or len(eds_paths) != 5:
        return {'status': 'FAIL_MISSING_CND_EVIDENCE', 'reference_cnd': str(reference_path), 'eds_cnd_count': len(eds_paths), 'geometry_exact_match': False, 'maximum_timestamp_offset_seconds': None, 'time_tolerance_seconds': time_tolerance_seconds, 'coindexed_for_counts_analysis': False}
    reference = parse_cnd_scan_metadata(reference_path)
    eds_metadata = [parse_cnd_scan_metadata(path) for path in eds_paths]
    required_reference = bool(reference['timestamp'] is not None and all((reference[key] is not None for key in ('pixels', 'pixel_size', 'dwell_ms', 'scan_direction', 'scan_mode', 'rotation_angle', 'line_direction'))) and (len(reference['stage_vertices']) == 5))
    geometry_match = bool(required_reference and all((_geometry_signature(metadata) == _geometry_signature(reference) for metadata in eds_metadata)))
    offsets = []
    if reference['timestamp'] is not None:
        for metadata in eds_metadata:
            if metadata['timestamp'] is None:
                offsets = []
                break
            offsets.append(abs((metadata['timestamp'] - reference['timestamp']).total_seconds()))
    maximum_offset = max(offsets) if len(offsets) == len(eds_metadata) else None
    time_match = bool(maximum_offset is not None and maximum_offset <= time_tolerance_seconds)
    accepted = geometry_match and time_match
    return {'status': 'COINDEXED' if accepted else 'FAIL_EDS_WDSA_NOT_PROVEN_COINDEXED', 'reference_cnd': str(reference_path), 'reference_timestamp': reference['timestamp_text'], 'eds_cnd_count': len(eds_paths), 'geometry_exact_match': geometry_match, 'stage_vertex_count': len(reference['stage_vertices']), 'maximum_timestamp_offset_seconds': maximum_offset, 'time_tolerance_seconds': time_tolerance_seconds, 'coindexed_for_counts_analysis': accepted, 'evidence_label': 'scan_metadata_comparison', 'evidence_basis': 'grid dimensions, pixel size, dwell, scan direction/mode/rotation/line direction, and five stage vertices compared field by field'}

def spatial_block_means(maps: dict[str, np.ndarray], include: np.ndarray, block_size: int, minimum_valid_fraction: float, *, include_partial_edge_blocks: bool=False) -> list[dict[str, Any]]:
    include = np.asarray(include, dtype=bool)
    arrays = {name: np.asarray(values, dtype=float) for name, values in maps.items()}
    if not arrays:
        raise ValueError('at least one map is required')
    if any((values.shape != include.shape for values in arrays.values())):
        raise ValueError('all count maps and include mask must have identical shapes')
    rows: list[dict[str, Any]] = []
    n_rows, n_columns = include.shape
    for row_start in range(0, n_rows, block_size):
        for column_start in range(0, n_columns, block_size):
            selector = include[row_start:row_start + block_size, column_start:column_start + block_size]
            if not include_partial_edge_blocks and selector.shape != (block_size, block_size):
                continue
            required = int(np.ceil(minimum_valid_fraction * selector.size))
            included = int(selector.sum())
            if included < required:
                continue
            row: dict[str, Any] = {'block_row': row_start // block_size, 'block_column': column_start // block_size, 'row_start_pixel': row_start, 'column_start_pixel': column_start, 'row_stop_pixel_exclusive': min(row_start + block_size, n_rows), 'column_stop_pixel_exclusive': min(column_start + block_size, n_columns), 'included_pixels': included, 'block_pixels': int(selector.size), 'valid_fraction': included / selector.size}
            for name, values in arrays.items():
                block = values[row_start:row_start + block_size, column_start:column_start + block_size]
                row[name] = float(block[selector].mean())
            rows.append(row)
    if not rows:
        raise ValueError('no spatial block met the minimum valid fraction')
    return rows

def _rank_percentile(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    if values.ndim != 1 or values.size < 2 or (not np.isfinite(values).all()):
        raise ValueError('rank input must be a finite 1-D array with at least two values')
    return (stats.rankdata(values, method='average') - 0.5) / values.size

def leave_one_element_out_score(counts: dict[str, np.ndarray], target_element: str) -> tuple[np.ndarray, tuple[str, ...]]:
    if set(counts) != set(ELEMENTS):
        raise ValueError('LOO rank analysis requires exactly Co, Cr, Fe, Mn, and Ni')
    if target_element not in counts:
        raise ValueError(f'unknown target element {target_element!r}')
    lengths = {np.asarray(values).size for values in counts.values()}
    if len(lengths) != 1:
        raise ValueError('all element count arrays must have equal length')
    predictors = tuple((element for element in ELEMENTS if element != target_element))
    oriented = []
    for element in predictors:
        rank = _rank_percentile(np.asarray(counts[element], dtype=float))
        oriented.append(rank if CORE_ORIENTATION[element] > 0.0 else 1.0 - rank)
    return (np.mean(np.vstack(oriented), axis=0), predictors)

@dataclass(frozen=True)
class RelativeCompositionConfig:
    block_size_pixels: int = 16
    minimum_block_valid_fraction: float = 0.75
    pole_fraction: float = 0.2
    bootstrap_replicates: int = 5000
    bootstrap_seed: int = 20260816
    nominal_atomic_fraction_each: float = 0.2
    native_border_pixels: int = 0

    def __post_init__(self) -> None:
        if self.block_size_pixels < 1:
            raise ValueError('block_size_pixels must be positive')
        if not 0.0 < self.minimum_block_valid_fraction <= 1.0:
            raise ValueError('minimum_block_valid_fraction must lie in (0, 1]')
        if not 0.0 < self.pole_fraction < 0.5:
            raise ValueError('pole_fraction must lie in (0, 0.5)')
        if self.bootstrap_replicates < 1:
            raise ValueError('bootstrap_replicates must be positive')
        if not math.isclose(self.nominal_atomic_fraction_each * len(ELEMENTS), 1.0, rel_tol=0.0, abs_tol=1e-12):
            raise ValueError('nominal atomic fractions must close to one')
        if self.native_border_pixels < 0:
            raise ValueError('native_border_pixels cannot be negative')

def fit_nominal_response_factors(records: Sequence[AcquisitionSignals], *, nominal_atomic_fraction_each: float=0.2) -> tuple[float, dict[str, float], dict[str, float]]:
    if not records:
        raise ValueError('at least one acquisition is required')
    reference_current_a = float(np.median([record.probe_current_a for record in records]))
    sums = {element: 0.0 for element in ELEMENTS}
    counts = {element: 0 for element in ELEMENTS}
    for record in records:
        if set(record.eds_maps) != set(ELEMENTS):
            raise ValueError('every acquisition must contain exactly five elements')
        correction = reference_current_a / record.probe_current_a
        include = np.asarray(record.include, dtype=bool)
        for element in ELEMENTS:
            values = np.asarray(record.eds_maps[element], dtype=float)
            if values.shape != include.shape:
                raise ValueError('map and mask shapes differ')
            selected = values[include] * correction
            if selected.size == 0 or not np.isfinite(selected).all():
                raise ValueError('response-factor fit has no valid finite signal')
            sums[element] += float(selected.sum())
            counts[element] += int(selected.size)
    means = {element: sums[element] / counts[element] for element in ELEMENTS}
    factors = {element: means[element] / nominal_atomic_fraction_each for element in ELEMENTS}
    if any((not np.isfinite(value) or value <= 0.0 for value in factors.values())):
        raise ValueError('fitted response factors must be finite and positive')
    return (reference_current_a, factors, means)

def relative_at_percent_maps(eds_maps: dict[str, np.ndarray], *, probe_current_a: float, reference_current_a: float, response_factors: dict[str, float]) -> dict[str, np.ndarray]:
    if set(eds_maps) != set(ELEMENTS) or set(response_factors) != set(ELEMENTS):
        raise ValueError('relative-at.% conversion requires exactly five elements')
    if probe_current_a <= 0.0 or reference_current_a <= 0.0:
        raise ValueError('probe currents must be positive')
    shapes = {np.asarray(values).shape for values in eds_maps.values()}
    if len(shapes) != 1:
        raise ValueError('all EDS maps must have the same shape')
    correction = reference_current_a / probe_current_a
    unclosed = {element: np.asarray(eds_maps[element], dtype=float) * correction / response_factors[element] for element in ELEMENTS}
    total = np.sum(np.stack([unclosed[element] for element in ELEMENTS]), axis=0)
    if not np.isfinite(total).all() or (total <= 0.0).any():
        raise ValueError('five-element corrected signal must be finite and positive')
    result = {element: 100.0 * unclosed[element] / total for element in ELEMENTS}
    closure = np.sum(np.stack([result[element] for element in ELEMENTS]), axis=0)
    if not np.allclose(closure, 100.0, rtol=0.0, atol=1e-10):
        raise RuntimeError('relative-at.% maps do not close to 100')
    return result

def _bootstrap_geometric_mean_ratio(ratios: np.ndarray, *, replicates: int, seed: int) -> tuple[float, float, float]:
    ratios = np.asarray(ratios, dtype=float)
    if ratios.ndim != 1 or ratios.size < 2 or (ratios <= 0.0).any():
        raise ValueError('bootstrap ratios must be a positive 1-D sample')
    log_values = np.log(ratios)
    rng = np.random.default_rng(seed)
    indices = rng.integers(0, ratios.size, size=(replicates, ratios.size))
    estimates = np.exp(log_values[indices].mean(axis=1))
    lower, upper = np.quantile(estimates, [0.025, 0.975])
    return (float(np.exp(log_values.mean())), float(lower), float(upper))


@dataclass(frozen=True)
class AcquisitionSignals:
    field: str
    probe_current_a: float
    include: np.ndarray
    eds_maps: dict[str, np.ndarray]


def load_fields(root: Path, order: list[str], config: RelativeCompositionConfig) -> list[AcquisitionSignals]:
    records = []
    for field in order:
        folder = root / field
        colocation = verify_eds_wdsa_colocation(folder)
        if not colocation["coindexed_for_counts_analysis"]:
            raise ValueError(f"EDS and BED-C scan geometry differs for {field}")
        maps = {element: load_count_map(folder / f"{element}_Kalpha_counts.csv") for element in ELEMENTS}
        bed = load_count_map(folder / "BED_C_counts.csv")
        if any(values.shape != bed.shape for values in maps.values()):
            raise ValueError(f"Count-map grids differ for {field}")
        include = bed > 0.0
        border = config.native_border_pixels
        if border:
            if 2 * border >= min(bed.shape):
                raise ValueError("Border consumes the complete count map")
            include[:border, :] = False
            include[-border:, :] = False
            include[:, :border] = False
            include[:, -border:] = False
        if not include.any():
            raise ValueError(f"No valid BED-C pixels for {field}")
        current = parse_acquisition_param(folder / "metadata/acquisition.param")["probe_current_a"]
        if current is None or not np.isfinite(current) or current <= 0.0:
            raise ValueError(f"Invalid probe current for {field}")
        records.append(AcquisitionSignals(field, float(current), include, maps))
    if len(records) != 6 or len({r.field for r in records}) != 6:
        raise ValueError("Exactly six distinct fields are required")
    return records


def chemical_region_contrasts(block_composition: dict[str, np.ndarray], pole_fraction: float) -> list[dict[str, Any]]:
    rows = []
    for target in ELEMENTS:
        target_values = np.asarray(block_composition[target], dtype=float)
        score, predictors = leave_one_element_out_score(block_composition, target)
        low_threshold, high_threshold = np.quantile(score, [pole_fraction, 1.0 - pole_fraction])
        interdendritic = score < low_threshold
        core = score > high_threshold
        minimum = max(3, int(math.ceil(0.05 * score.size)))
        if int(core.sum()) < minimum or int(interdendritic.sum()) < minimum:
            raise ValueError(f"Insufficient tie-safe pole blocks for {target}")
        core_value = float(np.median(target_values[core]))
        interdendritic_value = float(np.median(target_values[interdendritic]))
        rows.append({
            "element": target,
            "predictor_elements": ";".join(predictors),
            "included_blocks": int(score.size),
            "core_blocks": int(core.sum()),
            "interdendritic_blocks": int(interdendritic.sum()),
            "core_median_relative_at_percent": core_value,
            "interdendritic_median_relative_at_percent": interdendritic_value,
            "interdendritic_minus_core_at_percent": interdendritic_value - core_value,
            "apparent_core_interdendritic_ratio": core_value / interdendritic_value,
        })
    return rows


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def process(raw_root: Path, output: Path, settings: dict[str, Any]) -> None:
    config = RelativeCompositionConfig(**settings["analysis_parameters"])
    records = load_fields(raw_root, settings["field_processing_order"], config)
    reference_current, factors, means = fit_nominal_response_factors(records, nominal_atomic_fraction_each=config.nominal_atomic_fraction_each)
    output.mkdir(parents=True, exist_ok=False)
    response_rows = [{"element": element, "reference_probe_current_a": reference_current,
                      "pooled_current_corrected_mean_counts": means[element],
                      "counts_per_unit_atomic_fraction": factors[element]} for element in ELEMENTS]
    rows = []
    whole_field = []
    for record in records:
        maps = relative_at_percent_maps(record.eds_maps, probe_current_a=record.probe_current_a,
                                       reference_current_a=reference_current, response_factors=factors)
        np.savez_compressed(output / f"{record.field}_relative_composition.npz",
                            **{e: maps[e].astype(np.float32) for e in ELEMENTS}, include_mask=record.include)
        for element in ELEMENTS:
            values = maps[element][record.include]
            whole_field.append({"field": record.field, "element": element, "valid_pixels": int(values.size),
                                "mean_relative_at_percent": float(np.mean(values)),
                                "median_relative_at_percent": float(np.median(values)),
                                "std_relative_at_percent": float(np.std(values, ddof=0))})
        blocks = spatial_block_means(maps, record.include, config.block_size_pixels,
                                     config.minimum_block_valid_fraction, include_partial_edge_blocks=False)
        composition = {e: np.asarray([row[e] for row in blocks], dtype=float) for e in ELEMENTS}
        rows.extend({"field": record.field, **row} for row in chemical_region_contrasts(composition, config.pole_fraction))
    summaries = []
    for index, element in enumerate(ELEMENTS):
        selected = [row for row in rows if row["element"] == element]
        ratios = np.asarray([row["apparent_core_interdendritic_ratio"] for row in selected])
        estimate, lower, upper = _bootstrap_geometric_mean_ratio(ratios, replicates=config.bootstrap_replicates,
                                                               seed=config.bootstrap_seed + index)
        summaries.append({"element": element, "fields": len(selected), "geometric_mean_ratio": estimate,
                          "descriptive_bootstrap_95pct_lower": lower, "descriptive_bootstrap_95pct_upper": upper})
    write_csv(output / "response_factors.csv", response_rows)
    write_csv(output / "field_compositions.csv", sorted(whole_field, key=lambda r: (r["field"], r["element"])))
    write_csv(output / "chemical_region_compositions.csv", sorted(rows, key=lambda r: (r["field"], r["element"])))
    write_csv(output / "table_s1_mn_ratios.csv", [{"field": row["field"], "apparent_mn_ratio": row["apparent_core_interdendritic_ratio"]}
                                               for row in sorted(rows, key=lambda r: r["field"]) if row["element"] == "Mn"])
    write_csv(output / "element_summary.csv", summaries)
    print(f"Saved EPMA results to {output}")


def main() -> None:
    folder = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-data", type=Path, default=folder / "raw_data")
    parser.add_argument("--config", type=Path, default=folder / "analysis_parameters.json")
    parser.add_argument("--output", type=Path, default=folder / "results")
    args = parser.parse_args()
    process(args.raw_data, args.output, json.loads(args.config.read_text(encoding="utf-8")))


if __name__ == "__main__":
    main()
