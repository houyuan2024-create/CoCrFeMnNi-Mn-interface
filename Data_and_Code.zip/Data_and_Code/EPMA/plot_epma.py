"""Plot the EPMA quantities in Figures 2 and S1."""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from process_epma import ELEMENTS, load_count_map


def main() -> None:
    base = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-data", type=Path, default=base / "raw_data")
    parser.add_argument("--results", type=Path, default=base / "results")
    parser.add_argument("--output", type=Path, default=base / "figures")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    with (args.results / "chemical_region_compositions.csv").open(newline="") as stream:
        rows = {row["element"]: row for row in csv.DictReader(stream) if row["field"] == "field_01"}
    field = args.raw_data / "field_01"
    extent = (0, 256, 192, 0)
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "axes.spines.top": False,
                         "axes.spines.right": False, "pdf.fonttype": 42})
    fig, axs = plt.subplots(2, 2, figsize=(9, 7), layout="constrained")
    image = axs[0, 0].imshow(load_count_map(field / "Mn_Kalpha_counts.csv"), extent=extent, cmap="magma")
    axs[0, 0].set(xlabel="x (µm)", ylabel="y (µm)", title="(a) Mn Kα counts")
    fig.colorbar(image, ax=axs[0, 0], label="Counts")
    x = np.arange(len(ELEMENTS))
    core = [float(rows[e]["core_median_relative_at_percent"]) for e in ELEMENTS]
    interdendritic = [float(rows[e]["interdendritic_median_relative_at_percent"]) for e in ELEMENTS]
    axs[0, 1].bar(x - 0.18, core, width=0.36, label="Core-oriented", color="#3571A2")
    axs[0, 1].bar(x + 0.18, interdendritic, width=0.36, label="Interdendritic-oriented", color="#DB8540")
    axs[0, 1].set(xticks=x, xticklabels=ELEMENTS, ylabel="Relative composition (at.%)", title="(b) Chemical-region medians")
    axs[0, 1].set_ylim(0, 29)
    axs[0, 1].legend(fontsize=8, loc="upper right")
    difference = [float(rows[e]["interdendritic_minus_core_at_percent"]) for e in ELEMENTS]
    axs[1, 0].bar(x, difference, color=["#DB8540" if value > 0 else "#3571A2" for value in difference])
    axs[1, 0].axhline(0, color="black", linewidth=0.7)
    axs[1, 0].set(xticks=x, xticklabels=ELEMENTS, ylabel="Interdendritic − core (at.%)", title="(c) Composition difference")
    ratio = [float(rows[e]["apparent_core_interdendritic_ratio"]) for e in ELEMENTS]
    axs[1, 1].bar(x, ratio, color="#6B8092")
    axs[1, 1].axhline(1, color="black", linewidth=0.8, linestyle="--")
    axs[1, 1].set(xticks=x, xticklabels=ELEMENTS, ylabel="Apparent core/interdendritic ratio", title="(d) Apparent segregation ratio")
    for suffix in ("pdf", "png"):
        fig.savefig(args.output / f"figure_2.{suffix}", dpi=300)
    plt.close(fig)

    fig, axs = plt.subplots(2, 3, figsize=(11, 6), layout="constrained")
    channels = [("BED_C_counts.csv", "BED-C", "gray")] + [(f"{e}_Kalpha_counts.csv", f"{e} Kα", "magma") for e in ELEMENTS]
    for index, (axis, (filename, label, cmap)) in enumerate(zip(axs.flat, channels)):
        image = axis.imshow(load_count_map(field / filename), extent=extent, cmap=cmap)
        axis.set(xlabel="x (µm)", ylabel="y (µm)", title=f"({chr(97 + index)}) {label}")
        fig.colorbar(image, ax=axis, label="Counts")
    for suffix in ("pdf", "png"):
        fig.savefig(args.output / f"figure_s1.{suffix}", dpi=300)
    plt.close(fig)
    print(f"Saved EPMA figures to {args.output}")


if __name__ == "__main__":
    main()
