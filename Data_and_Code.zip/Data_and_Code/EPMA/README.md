# EPMA microsegregation analysis

Raw count maps and processing code for the EPMA results in Figure 2, Figure S1 and Table S1 of *Mn migration and liquid-side enrichment at CoCrFeMnNi solidification interfaces*.

## Contents

- `raw_data/field_01` to `raw_data/field_06`: six fields numbered as in Table S1. Each field contains five EDS Kα count maps, one BED-C count map, six acquisition-condition files and one acquisition-parameter export. Raw file contents are unchanged.
- `field_mapping.csv`: correspondence between field directories and manuscript items.
- `raw_file_checksums.csv`: SHA-256 hashes for the 78 raw files.
- `analysis_parameters.json`: numerical parameters, random seed and field processing order.
- `process_epma.py`: response normalization, chemical-region contrasts and field-resampling summaries.
- `plot_epma.py`: plots the quantities in Figures 2 and S1 from the raw maps and calculated tables.

The acquisition filenames identify the detector, element and quantity. `Kalpha_counts` contains raw counts, not calibrated composition. Each map has 400 × 300 pixels at 0.64 µm spacing. Instrument settings remain in the raw `.cnd` and `.param` exports.

## Run

The recorded environment is Python 3.12, NumPy 2.3.5, SciPy 1.18.1 and Matplotlib 3.11.2. From this directory:

```bash
python -m pip install -r requirements.txt
python process_epma.py
python plot_epma.py
```

`process_epma.py` creates `results/`. The principal outputs are:

| Output | Quantity |
|---|---|
| `chemical_region_compositions.csv` | Median relative composition and apparent ratio for each element and field |
| `table_s1_mn_ratios.csv` | Six Mn ratios in the manuscript field order |
| `element_summary.csv` | Geometric means and descriptive 95% field-resampling intervals |
| `response_factors.csv` | Pooled detector-response factors and reference current |
| `field_compositions.csv` | Whole-field relative-composition summaries |
| `field_01_relative_composition.npz` to `field_06_relative_composition.npz` | Relative-composition maps and valid-pixel masks |

`plot_epma.py` creates `figures/figure_2.pdf`, `figure_s1.pdf` and PNG copies. Use `--output` to select a new output directory; existing directories are not overwritten. For separate analysis and plot destinations:

```bash
python process_epma.py --output calculated_results
python plot_epma.py --results calculated_results --output calculated_figures
```

## Analysis definition

The beam-current correction uses the median current across all six fields. One response factor per element anchors the pooled mean signal to the nominal equiatomic composition. The five corrected channels are closed to 100 relative at.% at each pixel.

Nonpositive BED-C pixels are excluded. Valid pixels are averaged in complete 16 × 16 pixel blocks; a block requires at least 75% valid pixels. For each target element, the ranks of the other four elements define the chemical-region score. Co, Cr and Fe ranks increase towards the core-oriented end; Mn and Ni ranks increase towards the interdendritic-oriented end. Blocks strictly above the 80th percentile and below the 20th percentile define the two regions. The apparent ratio is the ratio of their target-element medians.

The six-field geometric mean and descriptive 95% interval use 5,000 bootstrap resamples. The processing order and random seed in `analysis_parameters.json` fix the resampling sequence; displayed table rows follow the manuscript field order.

Expected Mn ratios for fields 1–6, rounded to six decimals: `0.794395, 0.737953, 0.786721, 0.721129, 0.695599, 0.701461`. Their geometric mean is `0.738545`; the descriptive 95% range is `0.710228–0.770895`.

Relative at.% is semiquantitative and does not replace standards calibration, background subtraction or matrix corrections. The apparent ratios describe chemical-region contrast, not equilibrium partition coefficients. The six fields describe spatial variation within the available material, not six independently cast specimens.
